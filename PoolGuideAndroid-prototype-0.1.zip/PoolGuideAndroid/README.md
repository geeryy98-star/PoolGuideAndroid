# Pool Guide Android — prototipo 0.1

Proyecto inicial Android Studio para Redmi Note 13 Pro 5G / Android 16.

## Qué incluye
- Actividad inicial con permiso de superposición.
- Servicio en primer plano con menú flotante movible.
- Dos trazos de demostración al tocar el panel.

## Qué NO incluye todavía
- Captura de pantalla del juego.
- Detección automática de mesa, bolas o troneras.
- Cálculo real de trayectorias y rebotes.
- APK compilada o probada en un dispositivo.

## Abrir
1. Descomprime el ZIP.
2. Abre la carpeta `PoolGuideAndroid` desde Android Studio.
3. Deja que Gradle sincronice.
4. Ejecuta en un móvil Android 8 o posterior.
5. Concede el permiso de superposición y pulsa “Iniciar menú flotante”.

Este es código fuente de un prototipo, no una APK lista para instalar.
